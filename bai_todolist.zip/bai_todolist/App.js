
import React, { useState } from 'react';
import {View, Text, TextInput, TouchableOpacity, FlatList, CheckBox } from 'react-native';

export default function App() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([
    { id: 1, name: 'Vẽ tranh', completed: false },
    { id: 2, name: 'Ăn trưa', completed: false },
    { id: 3, name: 'Mua rau', completed: false }
  ]);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const handleAddTask = () => {
    if (task !== '') {
      const newTask = {
        id: Math.random().toString(),
        name: task,
        completed: false
      };
      setTasks([...tasks, newTask]);
      setTask('');
    }
  };

  const handleDeleteTask = (taskId) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };

  const toggleTaskCompletion = (taskId) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === taskId) {
        return { ...task, completed: !task.completed };
      }
      return task;
    });
    setTasks(updatedTasks);
  };

  const handleFilterChange = (value) => {
    setFilter(value);
  };

  const handleSearch = (value) => {
    setSearchTerm(value);
  };

  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') {
      return true;
    } else if (filter === 'completed') {
      return task.completed;
    } else {
      return !task.completed;
    }
  }).filter(task => task.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <View style={{ flex: 1, padding: 20,  }}>
      <Text style={{ fontSize: 30, fontWeight: 'bold', marginBottom: 10 , color: '#8B4513',marginLeft:'auto',marginRight:'auto'}}>TODO APP</Text>
      <View style={{  width: '106%',
    height: '90%',
    borderWidth: 5,
    borderColor: '#8B4513',
    borderRadius: 10,
    padding: 10,
    backgroundColor:'#FFEFD5'}}>
      <View style={{ flexDirection: 'row', marginBottom: 10 }}>
        <TextInput
          style={{ flex: 1, height: 40, borderColor: '#8B4513', borderWidth: 1, marginRight: 10, paddingHorizontal: 10,borderWidth:3, }}
          placeholder="Thêm nhiệm vụ"
          value={task}
          onChangeText={text => setTask(text)}
        />
        <TouchableOpacity style={{ backgroundColor: '#8B4513', justifyContent: 'center', paddingHorizontal: 10, borderWidth:3,borderColor: '#8B4513',}} onPress={handleAddTask}>
          <Text style={{ color: 'white' }}>Thêm</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        style={{ height: 40, borderColor: '#8B4513', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10, borderWidth:3, }}
        placeholder="Tìm kiếm nhiệm vụ"
        value={searchTerm}
        onChangeText={handleSearch}
      />

      <View style={{ flexDirection: 'row', marginBottom: 10 }}>
        <TouchableOpacity style={{ marginRight: 10 , }} onPress={() => handleFilterChange('all')}>
          <Text style={{ fontWeight: filter === 'all' ? 'bold' : 'normal',color: 'white',backgroundColor: '#8B4513',height: 20, }}>&nbsp;Tất cả&nbsp;</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{ marginRight: 10 }} onPress={() => handleFilterChange('completed')}>
          <Text style={{ fontWeight: filter === 'completed' ? 'bold' : 'normal',color: 'white',backgroundColor: '#8B4513',height: 20, }}>&nbsp;Đã hoàn thành&nbsp;</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => handleFilterChange('uncompleted')}>
          <Text style={{ fontWeight: filter === 'uncompleted' ? 'bold' : 'normal', color: 'white',backgroundColor: '#8B4513',height: 20, }}>&nbsp;Chưa hoàn thành&nbsp;</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredTasks}
        renderItem={({ item }) => (
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10,}}>

            <CheckBox style={{backgroundborderWidth: 3,borderColor: '#8B4513',}} value={item.completed} onValueChange={() => toggleTaskCompletion(item.id)} />
            <Text style={{ marginLeft: 10, textDecorationLine: item.completed ? 'none' : 'none' }}>{item.name}</Text>

            <TouchableOpacity style={{ marginLeft: 10  }} onPress={() => handleDeleteTask(item.id)}>

              <Text style={{ color: 'white',backgroundColor: 'gray',
    borderRadius: 4,}}>&nbsp;Xóa&nbsp;</Text>
            </TouchableOpacity>
          </View>
        )}
        keyExtractor={item => item.id}
      />
    </View>
    </View>
  );
}


